input('Hva heter du?');
navn='Sebastian';
fprintf('Mitt navn er %s.\n', navn);

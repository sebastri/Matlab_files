a=2;
V=((a^3)/12)*sqrt(2);
fprintf('V = %.2f\n', V);
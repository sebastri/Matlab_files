fahrenheit=100;
celsius=(fahrenheit-32)/1.8;
fprintf('Hva er temperaturen i fahrenheit? %d\n', fahrenheit);
fprintf('Den gitte temperaturen i fahrenheit er %.2f i celsius.\n', celsius);

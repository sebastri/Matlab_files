a=input('Skriv inn sidelengden p� teraedet: ');
V=((a^3)/12)*sqrt(2);
fprintf('Tetraedet med sidelengde %.2f, har volumet %.4f\n., ', a, V);
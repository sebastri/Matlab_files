r = 5;
fprintf('Vi har en sirkel med radius %d\n', r);
omkrets = 2*3.14*r;
fprintf('Omkretsen er %f\n', omkrets);
areal = 3.14*r^2;
fprintf('Arealet er %f\n', areal);
h = 8;
volum = areal*h;
fprintf('Sylinder med h�yde %d: ', h); fprintf('Volumet er %d.', volum);

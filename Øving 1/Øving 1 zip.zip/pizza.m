pizza=725;
studentrabatt=0.8;
tips=0.08*pizza;
sum=(pizza*studentrabatt-tips);
fprintf(sum);

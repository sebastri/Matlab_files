navn='Sebastian';
fprintf('Jeg heter %s.\n', navn);

navn=Sebastian
fprintf=('Mitt navn er %s', navn)

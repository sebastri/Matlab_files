function pluss = isPositive(N)

if N>0
    pluss=true;
else
    pluss=false;

end
function klasstall=isInteger(N)

if round(N)== N
    klasstall=true;
else 
    klasstall=false;
end

end

function sammenlign = compare(a,b)
if eq(a,b)
    sammenlign = true;
else
    sammenlign = false;
end
   

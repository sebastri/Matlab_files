function boolske = isEven2(N)
if mod(N, 2)== 0
    
    boolske=true;
else 
    boolske=false;
end 
end 
